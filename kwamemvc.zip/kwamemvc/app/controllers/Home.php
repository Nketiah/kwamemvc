<?php
 
 class Home extends Controller{

    public function __construct()
    {

    }

    public function index(){

       $data = ['title' => 'KwameMVC'];

      $this->view("index", $data);
    }

    public function about(){
       
    }
 }