<?php 
  require_once "../app/bootstrap.php";

  // init core libraries
  $core = new Core();